# Income And Expenses Tracking System using SQL Database and C# in Visual Studio
##Preview
![Dashboard](Previews/Dashboard.png)
![AddIncome](Previews/AddIncome.png)
![Expense](Previews/AddExpense.png)
![login](Previews/Login.png)
